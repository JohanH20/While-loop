using System;

class MainClass {
  public static void Main (string[] args) {
    Console.Write("Skriv ett tal mellan 1 och 100: ");
    int tal = int.Parse(Console.ReadLine());
    while(tal<=101)
    {
      Console.WriteLine(tal);
      tal++;
    }
  }
}